# JavaScript/WASM Binding

npm package name: `nirs4all`

The canonical source repository is `nirs4all-core`; the npm publication uses
the bare `nirs4all` name as the JavaScript/WASM aggregate surface. Python alone
uses the `nirs4all-core` distribution name to avoid colliding with the full
modelling library.

This package is the runtime surface that `nirs4all-web` should consume. The web
application lives in `nirs4all-web`; this directory is for the reusable
JavaScript/WASM binding and package metadata.

## Native assembled records

`loadIoAssembledWire()` lazily imports IO's `assembled-wire` entry from the
optional `@nirs4all/io-wasm` 0.3.8+ peer. Its `decodeAssembledFull(value)` function
converts the owner's native assembled schema 3 JSON into the logical arrays
returned by IO's `assembleDataset`, preserving identity, masks, axes, metadata
and packet precision. IO performs every decode and refusal; Core does not parse
the record, initialize WASM, assemble data or run scientific computation.

```javascript
import { loadIoAssembledWire } from 'nirs4all';

const { decodeAssembledFull } = await loadIoAssembledWire();
const dataset = decodeAssembledFull(JSON.parse(nativeRecordText));
```

The owner refuses unsupported schema versions or malformed packets. The optional
peer remains lazy; importing Core does not require IO to be installed.

## Canonical V1 `.n4a` exchange

The new library actions are `produceN4aNative`, `inspectN4aBytes`,
`predictN4aNative` and `retrainN4aNative`. Their source is being integrated with
the shared Core portable owner API; compiled exchange qualification is pending.
Use a matching local Core/DAG-ML/IO/Methods cohort until the coordinated V1
package release. This section does not claim support from older published packages.

The actions accept exact IO record and archive bytes. Core/IO derive identities
and prepare requests, DAG-ML schedules training, scoring, selection and replay,
and Methods owns fitted state and numerical operations. JavaScript marshals
arrays and selects callback rows by sample ID. It does not compile recipes or
replace missing state by fitting.

```javascript
import { produceN4aNative, predictN4aNative, retrainN4aNative } from 'nirs4all';

const trained = await produceN4aNative(trainingRecordBytes, {
  sourceId: 'spectra',
  recipe: {
    steps: [
      { method_id: 'preprocessing.scaling.standard_scale', role: 'transformer', params: {} },
      { method_id: 'models.regularized.ridge', role: 'regressor', params: { scale_x: false } },
    ],
    candidates: [{ alpha: 0.1 }, { alpha: 1.0 }],
  },
});
const prediction = await predictN4aNative(trained.archiveBytes, {
  entrypoint: 'predict-external',
  sourceId: 'spectra',
  record: predictionRecordBytes,
});
const retrained = await retrainN4aNative(trained.archiveBytes, newTrainingRecordBytes);
```

Production fits once and returns sealed `archiveBytes`. Retraining reads the
recipe from the validated archive; the caller supplies no replacement recipe.
Prediction exposes physical record-order `sampleIds` while preserving the signed
DAG replay unchanged. Align replay values by sample ID and target name. Inspection
returns the closed native-model view; readability alone does not grant execution.
Parsed JavaScript diagnostic views use JSON numbers; retain archive bytes and
exact owner JSON for identities or integers beyond JavaScript's exact range.

The first exchange gate targets single-source standard_scale/Ridge regression
with two complete targets, native Linux and Node WASM, including both prediction
directions and stored-recipe retraining. Other methods, browsers, classifiers,
partial targets and WASM calibration are not qualified by that gate. The dedicated
`n4a_wasm_exchange` Rust target drives `tests/n4a-exchange-driver.mjs`; missing
qualification inputs fail explicitly. Binding unit tests alone establish no
numerical portability.

### Generic `.n4a` storage (host payloads)

`openN4aContainer`, `writeN4aContainer` and `writeN4aStream` read and write any V1
`.n4a` container, including host-owned payloads Core cannot interpret. They are
storage only: only the Core WASM bridge is loaded, never Methods or DAG-ML, and no
owner payload is deserialized, trusted or executed. Readability is not executability;
`predictN4aNative` still refuses anything outside the supported native profile.

```javascript
import { openN4aContainer, writeN4aContainer, writeN4aStream } from 'nirs4all';

// Exact bytes held in WASM memory.
const { archiveBytes, receipt } = await writeN4aContainer(manifestJson, [
  { path: 'payloads/model.bin', bytes: hostModelBytes },
]);
const container = await openN4aContainer(archiveBytes);
try {
  container.view();                            // verified storage, `executability: 'not_evaluated'`
  container.manifestBytes();                   // exact stored manifest.json
  container.member('payloads/model.bin');      // exact bytes, or undefined
  container.artifactMembers('artifact:model'); // [{ path, bytes }, ...]
} finally {
  container.close();                           // frees the WASM allocation
}

// An archive that stays outside WASM memory: a File/Blob or { size, read(offset, length) }.
const external = await openN4aContainer(file, { memoryBudgetBytes: 64n * 1024n * 1024n });
try {
  for await (const chunk of external.memberStream('payloads/model.bin')) consume(chunk);
  // The last chunk arrives only after Core matched every byte read against the receipt.
  const whole = await external.readMember('payloads/small.json'); // allocates the whole member
} finally {
  external.close();
}

// Write without assembling the archive; sources are read twice (hash, then payload).
await writeN4aStream(manifestJson, [{ path: 'payloads/model.bin', source: file }], sink, { base: external });
```

**Sources.** Exact bytes are copied into WASM memory once and keep Core's full owner
semantic view. A `Blob`/`File`, or an object `{ size, read(offset, length) }` whose
arguments are BigInt and whose `read` resolves to exactly that range, stays outside
WASM: Core's scanner requests ranges, the host reads and feeds them, and only
validated metadata is retained. `view()` of such a container reports `semantics` and
`training_view` as `not_evaluated`, because no member bytes were read. The same
scanner serves every host; JavaScript parses no ZIP, computes no CRC and no hash.

**Verified streams.** `memberStream(path)` and `archiveStream()` re-read the source,
Core hashes the bytes actually returned and compares them with the validated receipt,
and the final chunk is delivered only after that comparison succeeds. Earlier chunks
are therefore unverified until the iteration finishes without throwing; a changed
source refuses with an integrity error. A bytes-held container streams from its
immutable WASM copy. `readMember` and `readArchive` materialize and verify the whole
range; `member`, `artifactMembers` and `archiveBytes` are synchronous and need a
bytes-held container.

**Budget.** `memoryBudgetBytes` (a safe integer, a BigInt or exact decimal text, never
rounded) is an optional declaration of authorized working memory for one operation.
Core admits an allocation against it before any wasm-bindgen copy and refuses with a
memory error. Without it Core declares no ceiling and imposes no limit on content size,
member count, manifest size or path length: only the allocator and the real host limits
below remain. The budget charges working allocations, never payload bytes that stay in
the source; the streaming chunk is derived by Core from the budget (a buffer size, not
a limit), so a budget below one chunk refuses. It does not detect or promise machine
memory. Every native action (`produceN4aNative`, `retrainN4aNative`,
`predictN4aNative`, `inspectN4aBytes`) accepts the same option.

**Writing.** Core derives each member's size, SHA-256 and CRC-32 and re-serializes the
manifest canonically, so whitespace and key order of the input are not kept; use the
original archive for an exact copy. `members` is an array so duplicate paths are
refused instead of collapsed. With `{ base }`, each member the manifest declares and
`members` omits comes from the base (digests from its validated inventory, bytes copied
verified); omitting a member from the manifest removes it. The base is never modified.
Owner identities stored inside replaced payloads are not recomputed.
`writeN4aContainer` assembles the archive in memory (it needs a bytes-held base).
`writeN4aStream` appends chunks to `sink = { write(chunk), close?(), abort?(error) }`
and resolves to `{ receipt }`. A source whose bytes changed between the two passes is
refused. On any failure after writing started, `abort(error)` is called and the sink
must be discarded: it may already hold bytes that were not verified. `close()` runs only
after Core confirmed the container SHA-256 of the bytes written.

**Real host limits** (reported as `n4a host limit` or as the engine's own error, never
as format limits): JavaScript safe integers (2^53 - 1) for `Blob` offsets and array
sizes, the engine's typed-array length when a whole member or archive is materialized,
and wasm32 linear memory, where an allocation that fails inside WASM traps instead of
returning a refusal. Archive paths are names inside the container, never
operating-system paths.

**Not qualified.** This source has not been compiled or run against a built bridge.
Not claimed: execution or scientific equivalence of host payloads, browser behaviour,
or behaviour at multi-gigabyte sizes. Native actions (`produce`, `retrain`, `predict`)
remain byte-based and bounded by WASM linear memory.

## Native execution and historical references

The JS portable runner and its coefficient DTOs have been retired. The package
does not export `runPortablePipeline`, `predictPortablePipeline` or
`parseExecutionPlan`, and does not convert legacy fitted JSON into owner packages.
Use the documented browser/native workflow and package routes for their declared
profiles, or `N4mRolePipeline` for Methods role recipes and trained v8 envelopes.

`loadPipelineDefinition` keeps JSON/YAML text, array and `pipeline` / `steps`
envelopes, comments, native augmentation parsing and Methods-manifest resolution
of `n4m:<method id>` tokens. Pass `{methods}` or await `loadMethodsWasm()` first.
Legacy class aliases are refused. `portableClassNames(definition)` extracts names
from supplied data; it is not a capability list or execution admission.
Parsing an augmentation declaration does not execute it or qualify a workflow.

Original JS source/tests are frozen as `.txt` under
[`tests/parity/reference/core-js-runner`](../../tests/parity/reference/core-js-runner/README.md).
The shared Python oracle and native/R augmentation fixture retain their bytes,
tolerances and provenance. Active `parity.test.js` checks MBPLS and GroupSparsePLS
directly through Methods; `native-augmentation.test.js` checks the 22 native/R
augmentation references. These primitive checks do not establish workflow parity.
The retained Core portable runner is MATLAB/Octave-only; its route is unchanged.

- `replayMethodsArchiveV2(archiveBytes, dataset)` validates the bounded Archive
  V2 stored-ZIP, manifest, inventory digests, DAG-ML package, execution bundle,
  and N4MM binding in Rust, then imports and predicts the single multi-target
  model through the public `@nirs4all/methods` C ABI. The native file reader and
  WASM byte reader compile the same Core-owned `archive_v2.rs` validation source;
  there is no second binding-owned archive parser. The JavaScript layer only
  validates host arrays and handles marshalling/ownership; it contains no
  numerical fallback and never fits a replacement model. Before import it also
  compares the manifest's capability-derived `abi_min_minor` with the actual
  Methods WASM `abiVersion()` and refuses an older runtime.

The Archive V2 WASM replay intentionally covers the Phase 2 portable Methods
PLS final-refit contract only. N4MM v2 preprocessing stays embedded in Methods
and therefore receives the raw matrix without a JavaScript kernel. Archives with multiple predictor
nodes, optimization checkpoints, conformal/robustness payloads, external or
host-only artifacts, undeclared inventory members, incompatible N4MM metadata,
or non-Methods dispatch are refused rather than silently approximated.

Build the Rust validator with `npm run build:native`. A qualification archive
and closed scenario can be replayed with:

```sh
npm run qualify:archive-v2 -- /path/to/archive.n4a /path/to/scenario.json
```

### Complete portable predictor transport

`writeNativePredictorPackage(containerId, outcomeBytes, packageBytes)` and
`writeNativeRefitPackage(containerId, packageBytes)` build a new owner-neutral
Core V1 container holding the native Package V2 / Package V3 scientific closure
from the exact DAG-ML JSON bytes; Core builds the closure through DAG-ML.
`readPortableArchiveV2(archiveBytes, { entrypoint, memoryBudgetBytes })` returns
`{ archiveId, archiveSha256, manifest, members, package, trainingOutcome, view }`
after Core validated the container and the selected closure: `package` is the
exact root package `Uint8Array`, `members` only the selected verified physical
members, `manifest` the neutral Core V1 manifest (there is no physical replay
map) and `trainingOutcome` is `null` for a standalone Package V3. There is no
intrinsic byte cap; only the optional host-authorized `memoryBudgetBytes`
bounds a call. Package V3 is readable and storable; WASM execution of Package V3
remains explicitly unsupported. All entrypoints reuse the same Core Rust source
as the file/Python surfaces; JavaScript implements no ZIP format or numerical
code. The old physical payload writer is removed; existing Package2/3 semantic
reader/replay names remain. Core retains RAW Methods state bytes, signed package
bindings and explicit runtime controller trust; it does not reinterpret one
state family as another. `replayMethodsArchiveV2` remains the separate closed
N4MM execution surface.

This transport supports a complete captured ensemble, including its learned
meta-model. It does not claim the canonical U07 N-D encoders or the same-DAG
R/Octave training profile.

The qualification command asserts the ordered two-dimensional result from one
model import and one multi-target prediction, checks that no Methods fit symbol
was called, and proves tampered-digest and inventory refusals. The isolated
tarball gate separately proves refusal when the optional Methods peer is absent.

Savitzky-Golay defaults to `mode: "interp"` for full nirs4all parity and
preserves explicit methods-backed modes (`mirror`, `constant`, `nearest`,
`wrap`, `interp`) plus `cval` in the serialized preprocessing chain.

## Generic n4m role recipes and trained envelopes (v8)

Any Methods estimator is a recipe step through the language-neutral token
`"n4m:<catalog method id>"` (or `{ class: "n4m:<id>", params }`), shared with
the full Python `nirs4all`, the R package and the Rust binding.
`loadPipelineDefinition(source, { methods })` accepts these tokens when they
resolve in the loaded Methods manifest (`methodClass`), next to the legacy
class names above; `n4mRoleCapabilities()` lists the usable steps from the
same manifest instead of a hand-maintained list.

`N4mRolePipeline` fits such a recipe (sample filters on training rows only,
transformers and selectors, then one regressor or classifier) in the native
Methods `RolePipeline`, which validates the recipe, passes every target column
to the steps that need `y`, checks the column names and refuses states that
contradict the recipe. It reads/writes the `nirs4all.n4m.trained_pipeline.v8`
envelope (`{schema, recipe, n_features, feature_names?, states: [{method_id,
n4me_base64, sha256, contains_training_rows, class_names?}]}`); envelopes
without `feature_names` / `contains_training_rows` still load. A pipeline
trained in Python or R replays in the browser from its N4ME states (level L2):

```js
import { N4mRolePipeline } from 'nirs4all';

const fitted = await N4mRolePipeline.fromJSON(envelopeText);
const { data } = fitted.predict({ X, rows, cols, featureNames }); // regressor
const { labels } = classifier.predict({ X, rows, cols });          // classifier
const trained = await N4mRolePipeline.fit(recipe, { X, rows, cols, y, featureNames });
const text = JSON.stringify(trained.toJSON({ allowTrainingRows: false }));
```

With `featureNames`, renamed or reordered columns are refused. Nested `X` and
`y` rows must match the declared `rows`/`cols` (every row is checked before
flattening). The import refuses an `n_features` that is not a positive
integer equal to the native width, a column name holding NUL, and a
`class_names` table that is not a non-empty list of unique strings or finite
numbers labelling every fitted class id (index = id). `recipe` is a copy of
the recipe the states attest, which is also the one exported. A state that
embeds training rows (kernel PLS, LW-PLS, ...) is exported only with
`toJSON({ allowTrainingRows: true })`. This path requires `@nirs4all/methods`
1.5.x (`~1.5.0`); the role-pipeline native format remains ABI 2.14.

Custom app hosts can inspect `executionProfiles()` (also embedded in
`capabilityManifest()` with `runtimeSurfaces`) before selecting a runtime. The
registry (`nirs4all-core.execution-profiles.v1`) declares exactly two supported
profiles, `native-workflow@1` and `native-conformal@1`, with per-operation
`supported`/`unsupported` entries (compile, fit, predict, import, export) and
the content types they carry (`nirs4all.native-pipeline.v1`;
`nirs4all.calibrated.v1`, a Core wrapper schema that JS/WASM itself never emits:
its calibrated import/export move the native archive V2 bytes). It is a metadata contract, not numerical certification. See
`docs/EXECUTION_PROFILES.md`.

## JavaScript model controllers

`createJsEstimatorController()` adapts a synchronous JavaScript estimator with
`fit(X, y)` (or `train(X, y)`) and `predict(X)` to DAG-ML's native
`HostControllerSpec`/`ControllerManifest` and `NodeTask`/`NodeResult` contracts.
Pass the initialized `dag-ml-wasm` module, a native DAG-ML `FoldSet`, and a
sample-ID-aligned numeric dataset. DAG-ML assigns folds, variants, phases and
64-bit seeds; the controller selects only each fold's training rows and emits
identity-keyed validation predictions. `REFIT` keeps the fitted JS object for
`PREDICT`. The public `createDagMlNodeResult()` helper lets browser clients
return the same wire result from an n4m-backed controller without duplicating
lineage or prediction serialization.

```js
import * as dagMl from 'dag-ml-wasm';
import { createRandomForestController } from 'nirs4all';

const controller = await createRandomForestController({
  dagMl, // initialize the WASM module before this call
  foldSet, // returned by dagMl.kfold_split_json / stratified_kfold_split_json
  dataset: { sampleIds, X, y },
});
const manifestsJson = JSON.stringify([controller.manifest]);
const resultsJson = dagMl.execute_execution_plan_phase_json(
  planJson, manifestsJson, 'run:example', 42, 'FIT_CV', controller.invoke,
);
```

Install the optional `ml-random-forest` peer to use that adapter. It supports
regression and numeric-class classification; `n_estimators` in pipeline params
maps to the library's `nEstimators` option. `fitFull()`/`predict()` and
`exportModel()`/`importModel()` serve simple host workflows. Other synchronous
classic-ML libraries can use `createJsEstimatorController()` directly. The JS
estimator's predictions are contract-compatible with DAG-ML, but numerical
parity with Python is only claimed for the n4m-backed portable methods path.
No browser Python or deep-learning training runtime is required.

`createN4mModelController()` uses the same fold/phase contract for any
coefficient-based `@nirs4all/methods` model supported by `fitModel()` and
`predictModel()`. Supply `modelType` (for example, `"PLSRegression"` or
`"Ridge"`) and an initialized Methods binding. DAG-ML params may contain
`n_components` and the Methods positional `params` vector. The adapter has
no numerical implementation; its fold predictions are tested against direct
Methods WASM calls at a `1e-12` absolute threshold.

### Classical JavaScript ML and sklearn-style interfaces

Import these optional adapters from `nirs4all/classic-ml`; the default entry
does not load their ML dependencies.
Call `loadMlJs()` or `loadScikitJs()` during setup, then pass the loaded module
to the synchronous controller factory. Fit, predict and DAG-ML callbacks stay
synchronous for the supported controllers.

`loadMlJs()` loads the optional [`ml`](https://github.com/mljs/ml) collection
on demand. `createMlJsEstimator()` wraps its random forests, decision trees and
k-nearest-neighbor classifier with `getParams()`, `setParams()`, `fit()` and
`predict()`. `createMlJsPca()` adds `fit()`, `transform()`, `fitTransform()` and
`inverseTransform()` around ml.js PCA. `createMlJsController()` connects the
supported supervised models to the native DAG-ML fold and phase contract. The
collection also exposes its matrix, decomposition and statistics tools directly
through `loadMlJs()`; this is a selected numerical toolbox, not the entire SciPy
API. Model JSON belongs to ml.js and is not a sklearn pickle or a portable n4m
artifact.

`loadScikitJs()` loads optional `scikitjs` and a compatible TensorFlow.js 3.x
backend only when requested. `createScikitJsEstimator()` exposes the same
structural estimator/transformer interface for its classes, preserving whether
their `fit()` returns immediately or returns a Promise. Its output tensors are
converted to ordinary arrays and disposed at the boundary. Sync decision-tree
classifiers and regressors can also use `createScikitJsController()` with the
native DAG-ML WASM scheduler. Other scikitjs estimators, including its linear
models, train asynchronously and cannot run inside the current synchronous
DAG-ML WASM callback. Their host API remains available; forcing a Promise into
the synchronous callback would break fold/seed validation. Scikitjs models use
`exportModelAsync()` and `importModelAsync()` on the DAG controller because its
serializer is asynchronous.

`createScikitJsAsyncController()` is the awaiting host counterpart. It offers
`invokeAsync()`, `fitFull()`, `predict()`, `exportModel()` and `importModel()` as
Promises for scikitjs classes such as `LinearRegression`. A host can pass it
native DAG-ML `NodeTask` records and await each result. It cannot be passed to
the current synchronous `dag-ml-wasm` phase callback: blocking that browser
worker would prevent the Promise from resolving. Native scheduler execution of
these estimators needs a DAG-ML async phase driver.

| Classical ML capability | This JS package | Web pipeline catalogue |
| --- | --- | --- |
| ml.js random forests, CART trees, KNN classifier | Synchronous DAG-ML controllers | Five model nodes |
| ml.js PCA | Host fit/transform/inverseTransform | No pipeline node |
| scikitjs trees | Synchronous DAG-ML controllers | No node |
| scikitjs async classes, e.g. LinearRegression | Awaiting host controller | No DAG-ML/Web node yet |
| Kanaries ML | Evaluated, no binding | No node |
| Torch, ONNX and neural-network training | No binding | No node |

`docs/CLASSIC_ML_JS.md` in the Core repository records qualification evidence,
the portable n4m scope, and remaining gaps. ML library JSON artifacts are
library-specific; only the n4m portable subset has a cross-language binary
and Python-oracle parity claim.

Both libraries are optional peer dependencies. They provide familiar classical
ML APIs in JavaScript, but no numerical equality with sklearn is claimed for
their independently implemented algorithms. Methods primitives and current role
envelopes have separate named reference checks; the old full-Python JS runner
comparison is historical.

For a browser-only custom host, pair this package with `nirs4all-ui`: keep
runtime loading and owner-backed execution in `nirs4all`, and consume shared React
components / view-model helpers / brand assets from `nirs4all-ui`. The
`nirs4all-web` browser app owns its worker, IO and storage integration. Consumer
production parity requires its own frozen-cohort evidence.
